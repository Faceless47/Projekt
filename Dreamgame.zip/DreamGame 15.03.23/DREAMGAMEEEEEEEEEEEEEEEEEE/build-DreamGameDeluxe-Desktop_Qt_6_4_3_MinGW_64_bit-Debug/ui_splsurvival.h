/********************************************************************************
** Form generated from reading UI file 'splsurvival.ui'
**
** Created by: Qt User Interface Compiler version 6.4.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SPLSURVIVAL_H
#define UI_SPLSURVIVAL_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_splSurvival
{
public:
    QPushButton *btnStand;
    QPushButton *btnHit;
    QLineEdit *leEinsatz;
    QTextEdit *txtedtCash;
    QPushButton *btnSwitch;

    void setupUi(QWidget *splSurvival)
    {
        if (splSurvival->objectName().isEmpty())
            splSurvival->setObjectName("splSurvival");
        splSurvival->resize(800, 600);
        btnStand = new QPushButton(splSurvival);
        btnStand->setObjectName("btnStand");
        btnStand->setGeometry(QRect(530, 470, 201, 61));
        QFont font;
        font.setFamilies({QString::fromUtf8("Palace Script MT")});
        font.setPointSize(36);
        font.setItalic(true);
        btnStand->setFont(font);
        btnHit = new QPushButton(splSurvival);
        btnHit->setObjectName("btnHit");
        btnHit->setGeometry(QRect(530, 380, 201, 61));
        btnHit->setFont(font);
        btnHit->setAutoFillBackground(false);
        btnHit->setCheckable(false);
        btnHit->setChecked(false);
        leEinsatz = new QLineEdit(splSurvival);
        leEinsatz->setObjectName("leEinsatz");
        leEinsatz->setGeometry(QRect(30, 130, 281, 81));
        QFont font1;
        font1.setFamilies({QString::fromUtf8("Niagara Solid")});
        font1.setPointSize(36);
        leEinsatz->setFont(font1);
        txtedtCash = new QTextEdit(splSurvival);
        txtedtCash->setObjectName("txtedtCash");
        txtedtCash->setGeometry(QRect(30, 40, 361, 61));
        btnSwitch = new QPushButton(splSurvival);
        btnSwitch->setObjectName("btnSwitch");
        btnSwitch->setGeometry(QRect(60, 470, 201, 61));
        btnSwitch->setFont(font);

        retranslateUi(splSurvival);

        QMetaObject::connectSlotsByName(splSurvival);
    } // setupUi

    void retranslateUi(QWidget *splSurvival)
    {
        splSurvival->setWindowTitle(QCoreApplication::translate("splSurvival", "Form", nullptr));
        btnStand->setText(QCoreApplication::translate("splSurvival", "stand", nullptr));
        btnHit->setText(QCoreApplication::translate("splSurvival", "hit", nullptr));
        leEinsatz->setText(QCoreApplication::translate("splSurvival", "Einsatz :", nullptr));
        txtedtCash->setHtml(QCoreApplication::translate("splSurvival", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'MS Shell Dlg 2'; font-size:8.25pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:28pt;\">Kontostand : </span></p></body></html>", nullptr));
        btnSwitch->setText(QCoreApplication::translate("splSurvival", "Tisch wechseln", nullptr));
    } // retranslateUi

};

namespace Ui {
    class splSurvival: public Ui_splSurvival {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SPLSURVIVAL_H
