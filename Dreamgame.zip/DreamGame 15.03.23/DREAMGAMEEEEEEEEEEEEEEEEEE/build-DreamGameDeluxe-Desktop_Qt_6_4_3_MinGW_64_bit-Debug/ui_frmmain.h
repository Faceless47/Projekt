/********************************************************************************
** Form generated from reading UI file 'frmmain.ui'
**
** Created by: Qt User Interface Compiler version 6.4.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FRMMAIN_H
#define UI_FRMMAIN_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_frmMain
{
public:
    QWidget *centralwidget;
    QPushButton *btnRegister;
    QPushButton *btnLogin;
    QLabel *lblpic;

    void setupUi(QMainWindow *frmMain)
    {
        if (frmMain->objectName().isEmpty())
            frmMain->setObjectName("frmMain");
        frmMain->resize(800, 600);
        centralwidget = new QWidget(frmMain);
        centralwidget->setObjectName("centralwidget");
        btnRegister = new QPushButton(centralwidget);
        btnRegister->setObjectName("btnRegister");
        btnRegister->setGeometry(QRect(440, 520, 221, 71));
        btnLogin = new QPushButton(centralwidget);
        btnLogin->setObjectName("btnLogin");
        btnLogin->setGeometry(QRect(150, 520, 201, 71));
        lblpic = new QLabel(centralwidget);
        lblpic->setObjectName("lblpic");
        lblpic->setGeometry(QRect(-80, 0, 941, 601));
        lblpic->setPixmap(QPixmap(QString::fromUtf8("../../Desktop/projekt sschule/welcomescreen.png")));
        lblpic->setScaledContents(true);
        frmMain->setCentralWidget(centralwidget);
        lblpic->raise();
        btnRegister->raise();
        btnLogin->raise();

        retranslateUi(frmMain);

        QMetaObject::connectSlotsByName(frmMain);
    } // setupUi

    void retranslateUi(QMainWindow *frmMain)
    {
        frmMain->setWindowTitle(QCoreApplication::translate("frmMain", "frmMain", nullptr));
        btnRegister->setText(QCoreApplication::translate("frmMain", "Register", nullptr));
        btnLogin->setText(QCoreApplication::translate("frmMain", "Login", nullptr));
        lblpic->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class frmMain: public Ui_frmMain {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FRMMAIN_H
