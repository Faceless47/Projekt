/********************************************************************************
** Form generated from reading UI file 'splblitz.ui'
**
** Created by: Qt User Interface Compiler version 6.4.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SPLBLITZ_H
#define UI_SPLBLITZ_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QTimeEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_splBlitz
{
public:
    QPushButton *btnSwitch;
    QPushButton *btnHit;
    QTimeEdit *tmedtTimer;
    QPushButton *btnStand;
    QTextEdit *txtedtCash;
    QLineEdit *leEinsatz;

    void setupUi(QWidget *splBlitz)
    {
        if (splBlitz->objectName().isEmpty())
            splBlitz->setObjectName("splBlitz");
        splBlitz->resize(800, 600);
        btnSwitch = new QPushButton(splBlitz);
        btnSwitch->setObjectName("btnSwitch");
        btnSwitch->setGeometry(QRect(40, 520, 201, 61));
        QFont font;
        font.setFamilies({QString::fromUtf8("Palace Script MT")});
        font.setPointSize(36);
        font.setItalic(true);
        btnSwitch->setFont(font);
        btnHit = new QPushButton(splBlitz);
        btnHit->setObjectName("btnHit");
        btnHit->setGeometry(QRect(560, 420, 201, 61));
        btnHit->setFont(font);
        tmedtTimer = new QTimeEdit(splBlitz);
        tmedtTimer->setObjectName("tmedtTimer");
        tmedtTimer->setGeometry(QRect(560, 20, 211, 101));
        QFont font1;
        font1.setPointSize(24);
        tmedtTimer->setFont(font1);
        btnStand = new QPushButton(splBlitz);
        btnStand->setObjectName("btnStand");
        btnStand->setGeometry(QRect(560, 510, 201, 61));
        btnStand->setFont(font);
        txtedtCash = new QTextEdit(splBlitz);
        txtedtCash->setObjectName("txtedtCash");
        txtedtCash->setGeometry(QRect(30, 30, 381, 61));
        leEinsatz = new QLineEdit(splBlitz);
        leEinsatz->setObjectName("leEinsatz");
        leEinsatz->setGeometry(QRect(30, 120, 281, 81));
        QFont font2;
        font2.setFamilies({QString::fromUtf8("Niagara Solid")});
        font2.setPointSize(36);
        leEinsatz->setFont(font2);
        btnHit->raise();
        tmedtTimer->raise();
        btnStand->raise();
        txtedtCash->raise();
        leEinsatz->raise();
        btnSwitch->raise();

        retranslateUi(splBlitz);

        QMetaObject::connectSlotsByName(splBlitz);
    } // setupUi

    void retranslateUi(QWidget *splBlitz)
    {
        splBlitz->setWindowTitle(QCoreApplication::translate("splBlitz", "Form", nullptr));
        btnSwitch->setText(QCoreApplication::translate("splBlitz", "Tisch wechseln", nullptr));
        btnHit->setText(QCoreApplication::translate("splBlitz", "hit", nullptr));
        btnStand->setText(QCoreApplication::translate("splBlitz", "stand", nullptr));
        txtedtCash->setHtml(QCoreApplication::translate("splBlitz", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'MS Shell Dlg 2'; font-size:8.25pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:28pt;\">Kontostand :</span></p></body></html>", nullptr));
        leEinsatz->setText(QCoreApplication::translate("splBlitz", "Einsatz :", nullptr));
    } // retranslateUi

};

namespace Ui {
    class splBlitz: public Ui_splBlitz {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SPLBLITZ_H
