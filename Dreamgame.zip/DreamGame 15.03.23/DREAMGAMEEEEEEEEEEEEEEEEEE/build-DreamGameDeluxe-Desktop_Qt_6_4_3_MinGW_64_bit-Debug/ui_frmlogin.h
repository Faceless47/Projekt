/********************************************************************************
** Form generated from reading UI file 'frmlogin.ui'
**
** Created by: Qt User Interface Compiler version 6.4.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FRMLOGIN_H
#define UI_FRMLOGIN_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_frmLogin
{
public:
    QLineEdit *lePassword;
    QLineEdit *leUName;
    QLabel *lblCmd;
    QLabel *lblPic;
    QLabel *lblCnct;
    QPushButton *btnLogin;

    void setupUi(QWidget *frmLogin)
    {
        if (frmLogin->objectName().isEmpty())
            frmLogin->setObjectName("frmLogin");
        frmLogin->resize(800, 600);
        lePassword = new QLineEdit(frmLogin);
        lePassword->setObjectName("lePassword");
        lePassword->setGeometry(QRect(50, 260, 301, 71));
        lePassword->setEchoMode(QLineEdit::Password);
        leUName = new QLineEdit(frmLogin);
        leUName->setObjectName("leUName");
        leUName->setEnabled(true);
        leUName->setGeometry(QRect(50, 160, 301, 71));
        QFont font;
        font.setBold(false);
        leUName->setFont(font);
        leUName->setClearButtonEnabled(false);
        lblCmd = new QLabel(frmLogin);
        lblCmd->setObjectName("lblCmd");
        lblCmd->setGeometry(QRect(40, 60, 351, 71));
        QFont font1;
        font1.setFamilies({QString::fromUtf8("Monotype Corsiva")});
        font1.setPointSize(24);
        font1.setItalic(true);
        lblCmd->setFont(font1);
        lblPic = new QLabel(frmLogin);
        lblPic->setObjectName("lblPic");
        lblPic->setGeometry(QRect(0, 0, 801, 601));
        lblPic->setFont(font1);
        lblPic->setPixmap(QPixmap(QString::fromUtf8("../../Desktop/projekt sschule/black dg.png")));
        lblPic->setScaledContents(true);
        lblCnct = new QLabel(frmLogin);
        lblCnct->setObjectName("lblCnct");
        lblCnct->setGeometry(QRect(270, 380, 511, 211));
        lblCnct->setFont(font1);
        btnLogin = new QPushButton(frmLogin);
        btnLogin->setObjectName("btnLogin");
        btnLogin->setGeometry(QRect(50, 410, 161, 61));
        lblPic->raise();
        lePassword->raise();
        leUName->raise();
        lblCmd->raise();
        lblCnct->raise();
        btnLogin->raise();

        retranslateUi(frmLogin);

        QMetaObject::connectSlotsByName(frmLogin);
    } // setupUi

    void retranslateUi(QWidget *frmLogin)
    {
        frmLogin->setWindowTitle(QCoreApplication::translate("frmLogin", "Form", nullptr));
        lePassword->setText(QCoreApplication::translate("frmLogin", "1234", nullptr));
        lePassword->setPlaceholderText(QCoreApplication::translate("frmLogin", "Password", nullptr));
        leUName->setText(QCoreApplication::translate("frmLogin", "Admin", nullptr));
        leUName->setPlaceholderText(QCoreApplication::translate("frmLogin", "Username", nullptr));
        lblCmd->setText(QCoreApplication::translate("frmLogin", "bitte melden sie sich an", nullptr));
        lblPic->setText(QString());
        lblCnct->setText(QCoreApplication::translate("frmLogin", "Verbindung zum server wird hergestellt... \n"
"  \n"
"  wenn sie nicht verbunden werden, \n"
" starten sie das Programm neu oder  \n"
" melden sie sich an den Programmierern", nullptr));
        btnLogin->setText(QCoreApplication::translate("frmLogin", "Login", nullptr));
    } // retranslateUi

};

namespace Ui {
    class frmLogin: public Ui_frmLogin {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FRMLOGIN_H
