/********************************************************************************
** Form generated from reading UI file 'frmregister.ui'
**
** Created by: Qt User Interface Compiler version 6.4.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FRMREGISTER_H
#define UI_FRMREGISTER_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_frmRegister
{
public:
    QLabel *lblname;
    QLineEdit *leUPassword;
    QLabel *lblPass;
    QPushButton *btnReg;
    QLabel *lblPic;
    QLineEdit *leUName;
    QLineEdit *leUPassword_2;

    void setupUi(QWidget *frmRegister)
    {
        if (frmRegister->objectName().isEmpty())
            frmRegister->setObjectName("frmRegister");
        frmRegister->resize(800, 600);
        lblname = new QLabel(frmRegister);
        lblname->setObjectName("lblname");
        lblname->setGeometry(QRect(60, 66, 321, 20));
        QFont font;
        font.setPointSize(18);
        lblname->setFont(font);
        leUPassword = new QLineEdit(frmRegister);
        leUPassword->setObjectName("leUPassword");
        leUPassword->setGeometry(QRect(60, 270, 201, 61));
        QFont font1;
        font1.setPointSize(14);
        leUPassword->setFont(font1);
        leUPassword->setEchoMode(QLineEdit::Password);
        lblPass = new QLabel(frmRegister);
        lblPass->setObjectName("lblPass");
        lblPass->setGeometry(QRect(60, 230, 271, 31));
        lblPass->setFont(font);
        btnReg = new QPushButton(frmRegister);
        btnReg->setObjectName("btnReg");
        btnReg->setGeometry(QRect(400, 420, 321, 111));
        QFont font2;
        font2.setPointSize(16);
        btnReg->setFont(font2);
        lblPic = new QLabel(frmRegister);
        lblPic->setObjectName("lblPic");
        lblPic->setGeometry(QRect(0, 0, 801, 601));
        lblPic->setFont(font);
        lblPic->setPixmap(QPixmap(QString::fromUtf8("../../Desktop/projekt sschule/green dg.png")));
        lblPic->setScaledContents(true);
        leUName = new QLineEdit(frmRegister);
        leUName->setObjectName("leUName");
        leUName->setGeometry(QRect(60, 100, 201, 61));
        leUName->setFont(font1);
        leUPassword_2 = new QLineEdit(frmRegister);
        leUPassword_2->setObjectName("leUPassword_2");
        leUPassword_2->setGeometry(QRect(60, 360, 201, 61));
        leUPassword_2->setFont(font1);
        leUPassword_2->setEchoMode(QLineEdit::Password);
        lblPic->raise();
        lblname->raise();
        leUPassword->raise();
        lblPass->raise();
        btnReg->raise();
        leUName->raise();
        leUPassword_2->raise();

        retranslateUi(frmRegister);

        QMetaObject::connectSlotsByName(frmRegister);
    } // setupUi

    void retranslateUi(QWidget *frmRegister)
    {
        frmRegister->setWindowTitle(QCoreApplication::translate("frmRegister", "Form", nullptr));
        lblname->setText(QCoreApplication::translate("frmRegister", "w\303\244hlen sie einen Usernamen", nullptr));
        leUPassword->setText(QString());
        leUPassword->setPlaceholderText(QCoreApplication::translate("frmRegister", "Passwort", nullptr));
        lblPass->setText(QCoreApplication::translate("frmRegister", "w\303\244hlen sie ein Passwort", nullptr));
        btnReg->setText(QCoreApplication::translate("frmRegister", "registrieren", nullptr));
        lblPic->setText(QString());
        leUName->setText(QString());
        leUName->setPlaceholderText(QCoreApplication::translate("frmRegister", "Username", nullptr));
        leUPassword_2->setText(QString());
        leUPassword_2->setPlaceholderText(QCoreApplication::translate("frmRegister", "Passwort wiederholen", nullptr));
    } // retranslateUi

};

namespace Ui {
    class frmRegister: public Ui_frmRegister {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FRMREGISTER_H
