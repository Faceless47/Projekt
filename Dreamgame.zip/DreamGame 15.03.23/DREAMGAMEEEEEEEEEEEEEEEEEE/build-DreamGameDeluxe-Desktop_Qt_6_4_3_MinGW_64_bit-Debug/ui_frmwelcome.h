/********************************************************************************
** Form generated from reading UI file 'frmwelcome.ui'
**
** Created by: Qt User Interface Compiler version 6.4.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FRMWELCOME_H
#define UI_FRMWELCOME_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_frmWelcome
{
public:
    QPushButton *btnBlitz;
    QLabel *lblCash;
    QPushButton *btnStd;
    QPushButton *btnSvvl;
    QLabel *lblWelcome;
    QLabel *lblPic;

    void setupUi(QWidget *frmWelcome)
    {
        if (frmWelcome->objectName().isEmpty())
            frmWelcome->setObjectName("frmWelcome");
        frmWelcome->resize(800, 600);
        btnBlitz = new QPushButton(frmWelcome);
        btnBlitz->setObjectName("btnBlitz");
        btnBlitz->setGeometry(QRect(30, 440, 201, 111));
        QFont font;
        font.setPointSize(16);
        btnBlitz->setFont(font);
        lblCash = new QLabel(frmWelcome);
        lblCash->setObjectName("lblCash");
        lblCash->setGeometry(QRect(20, 120, 211, 51));
        QFont font1;
        font1.setPointSize(20);
        lblCash->setFont(font1);
        lblCash->setAutoFillBackground(true);
        btnStd = new QPushButton(frmWelcome);
        btnStd->setObjectName("btnStd");
        btnStd->setGeometry(QRect(280, 440, 201, 111));
        btnStd->setFont(font);
        btnSvvl = new QPushButton(frmWelcome);
        btnSvvl->setObjectName("btnSvvl");
        btnSvvl->setGeometry(QRect(560, 440, 191, 111));
        btnSvvl->setFont(font);
        lblWelcome = new QLabel(frmWelcome);
        lblWelcome->setObjectName("lblWelcome");
        lblWelcome->setGeometry(QRect(20, 30, 511, 61));
        QFont font2;
        font2.setFamilies({QString::fromUtf8("Palatino Linotype")});
        font2.setPointSize(12);
        lblWelcome->setFont(font2);
        lblWelcome->setAutoFillBackground(true);
        lblWelcome->setScaledContents(false);
        lblWelcome->setOpenExternalLinks(false);
        lblPic = new QLabel(frmWelcome);
        lblPic->setObjectName("lblPic");
        lblPic->setGeometry(QRect(0, 0, 801, 601));
        lblPic->setPixmap(QPixmap(QString::fromUtf8("../../Desktop/projekt sschule/blue dg.png")));
        lblPic->setScaledContents(true);
        lblPic->raise();
        btnBlitz->raise();
        lblCash->raise();
        btnStd->raise();
        btnSvvl->raise();
        lblWelcome->raise();

        retranslateUi(frmWelcome);

        QMetaObject::connectSlotsByName(frmWelcome);
    } // setupUi

    void retranslateUi(QWidget *frmWelcome)
    {
        frmWelcome->setWindowTitle(QCoreApplication::translate("frmWelcome", "Form", nullptr));
        btnBlitz->setText(QCoreApplication::translate("frmWelcome", "Blitz", nullptr));
        lblCash->setText(QCoreApplication::translate("frmWelcome", "cash:", nullptr));
        btnStd->setText(QCoreApplication::translate("frmWelcome", "Standard", nullptr));
        btnSvvl->setText(QCoreApplication::translate("frmWelcome", "survival", nullptr));
        lblWelcome->setText(QString());
        lblPic->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class frmWelcome: public Ui_frmWelcome {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FRMWELCOME_H
