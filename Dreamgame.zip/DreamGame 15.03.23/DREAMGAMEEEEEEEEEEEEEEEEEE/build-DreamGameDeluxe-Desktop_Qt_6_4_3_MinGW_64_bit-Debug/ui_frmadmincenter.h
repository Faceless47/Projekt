/********************************************************************************
** Form generated from reading UI file 'frmadmincenter.ui'
**
** Created by: Qt User Interface Compiler version 6.4.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FRMADMINCENTER_H
#define UI_FRMADMINCENTER_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_frmAdminCenter
{
public:
    QPushButton *btnLogout;
    QComboBox *cboxUser;
    QListWidget *lwUData;
    QLabel *lblUserInf;
    QPushButton *btnCngMoney;
    QPushButton *btnPlay;
    QPushButton *btnDltUser;
    QLabel *lblUserSlct;
    QPushButton *lblSave;
    QLabel *lblPic;

    void setupUi(QWidget *frmAdminCenter)
    {
        if (frmAdminCenter->objectName().isEmpty())
            frmAdminCenter->setObjectName("frmAdminCenter");
        frmAdminCenter->resize(800, 600);
        btnLogout = new QPushButton(frmAdminCenter);
        btnLogout->setObjectName("btnLogout");
        btnLogout->setGeometry(QRect(30, 520, 161, 61));
        cboxUser = new QComboBox(frmAdminCenter);
        cboxUser->addItem(QString());
        cboxUser->addItem(QString());
        cboxUser->addItem(QString());
        cboxUser->addItem(QString());
        cboxUser->setObjectName("cboxUser");
        cboxUser->setGeometry(QRect(30, 100, 301, 41));
        lwUData = new QListWidget(frmAdminCenter);
        lwUData->setObjectName("lwUData");
        lwUData->setGeometry(QRect(20, 220, 711, 201));
        lblUserInf = new QLabel(frmAdminCenter);
        lblUserInf->setObjectName("lblUserInf");
        lblUserInf->setGeometry(QRect(20, 150, 291, 61));
        QFont font;
        font.setPointSize(14);
        lblUserInf->setFont(font);
        btnCngMoney = new QPushButton(frmAdminCenter);
        btnCngMoney->setObjectName("btnCngMoney");
        btnCngMoney->setGeometry(QRect(580, 520, 161, 61));
        btnPlay = new QPushButton(frmAdminCenter);
        btnPlay->setObjectName("btnPlay");
        btnPlay->setGeometry(QRect(210, 520, 161, 61));
        btnDltUser = new QPushButton(frmAdminCenter);
        btnDltUser->setObjectName("btnDltUser");
        btnDltUser->setGeometry(QRect(390, 520, 161, 61));
        lblUserSlct = new QLabel(frmAdminCenter);
        lblUserSlct->setObjectName("lblUserSlct");
        lblUserSlct->setGeometry(QRect(30, 70, 251, 21));
        lblUserSlct->setFont(font);
        lblSave = new QPushButton(frmAdminCenter);
        lblSave->setObjectName("lblSave");
        lblSave->setGeometry(QRect(30, 450, 161, 61));
        lblPic = new QLabel(frmAdminCenter);
        lblPic->setObjectName("lblPic");
        lblPic->setGeometry(QRect(0, 0, 801, 601));
        lblPic->setPixmap(QPixmap(QString::fromUtf8("../../Desktop/projekt sschule/orange dg.png")));
        lblPic->setScaledContents(true);
        lblPic->raise();
        btnLogout->raise();
        cboxUser->raise();
        lwUData->raise();
        lblUserInf->raise();
        btnCngMoney->raise();
        btnPlay->raise();
        btnDltUser->raise();
        lblUserSlct->raise();
        lblSave->raise();

        retranslateUi(frmAdminCenter);

        QMetaObject::connectSlotsByName(frmAdminCenter);
    } // setupUi

    void retranslateUi(QWidget *frmAdminCenter)
    {
        frmAdminCenter->setWindowTitle(QCoreApplication::translate("frmAdminCenter", "Form", nullptr));
        btnLogout->setText(QCoreApplication::translate("frmAdminCenter", "logout", nullptr));
        cboxUser->setItemText(0, QCoreApplication::translate("frmAdminCenter", "Neues Element1", nullptr));
        cboxUser->setItemText(1, QCoreApplication::translate("frmAdminCenter", "Neues Element2", nullptr));
        cboxUser->setItemText(2, QCoreApplication::translate("frmAdminCenter", "Neues Element", nullptr));
        cboxUser->setItemText(3, QCoreApplication::translate("frmAdminCenter", "Neues Element", nullptr));

        lblUserInf->setText(QCoreApplication::translate("frmAdminCenter", "user informationen", nullptr));
        btnCngMoney->setText(QCoreApplication::translate("frmAdminCenter", "geld bearbeiten", nullptr));
        btnPlay->setText(QCoreApplication::translate("frmAdminCenter", "zum welcomescreen", nullptr));
        btnDltUser->setText(QCoreApplication::translate("frmAdminCenter", "nutzer l\303\266schen", nullptr));
        lblUserSlct->setText(QCoreApplication::translate("frmAdminCenter", "user W\303\244hlen", nullptr));
        lblSave->setText(QCoreApplication::translate("frmAdminCenter", "\303\244nderrungen speichern", nullptr));
        lblPic->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class frmAdminCenter: public Ui_frmAdminCenter {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FRMADMINCENTER_H
