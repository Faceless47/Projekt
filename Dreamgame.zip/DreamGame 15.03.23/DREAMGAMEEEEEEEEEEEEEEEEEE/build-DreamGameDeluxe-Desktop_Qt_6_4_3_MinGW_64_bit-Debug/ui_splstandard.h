/********************************************************************************
** Form generated from reading UI file 'splstandard.ui'
**
** Created by: Qt User Interface Compiler version 6.4.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SPLSTANDARD_H
#define UI_SPLSTANDARD_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_splStandard
{
public:
    QPushButton *btnStand;
    QPushButton *btnHit;
    QLineEdit *leEinsatz;
    QTextEdit *txtedtCash;
    QPushButton *btnSwitch;

    void setupUi(QWidget *splStandard)
    {
        if (splStandard->objectName().isEmpty())
            splStandard->setObjectName("splStandard");
        splStandard->resize(800, 600);
        btnStand = new QPushButton(splStandard);
        btnStand->setObjectName("btnStand");
        btnStand->setGeometry(QRect(520, 460, 201, 61));
        QFont font;
        font.setFamilies({QString::fromUtf8("Palace Script MT")});
        font.setPointSize(36);
        font.setItalic(true);
        btnStand->setFont(font);
        btnHit = new QPushButton(splStandard);
        btnHit->setObjectName("btnHit");
        btnHit->setGeometry(QRect(520, 370, 201, 61));
        btnHit->setFont(font);
        leEinsatz = new QLineEdit(splStandard);
        leEinsatz->setObjectName("leEinsatz");
        leEinsatz->setGeometry(QRect(20, 120, 281, 81));
        QFont font1;
        font1.setFamilies({QString::fromUtf8("Niagara Solid")});
        font1.setPointSize(36);
        leEinsatz->setFont(font1);
        txtedtCash = new QTextEdit(splStandard);
        txtedtCash->setObjectName("txtedtCash");
        txtedtCash->setGeometry(QRect(20, 30, 361, 61));
        btnSwitch = new QPushButton(splStandard);
        btnSwitch->setObjectName("btnSwitch");
        btnSwitch->setGeometry(QRect(50, 460, 201, 61));
        btnSwitch->setFont(font);
        leEinsatz->raise();
        txtedtCash->raise();
        btnSwitch->raise();
        btnStand->raise();
        btnHit->raise();

        retranslateUi(splStandard);

        QMetaObject::connectSlotsByName(splStandard);
    } // setupUi

    void retranslateUi(QWidget *splStandard)
    {
        splStandard->setWindowTitle(QCoreApplication::translate("splStandard", "Form", nullptr));
        btnStand->setText(QCoreApplication::translate("splStandard", "stand", nullptr));
        btnHit->setText(QCoreApplication::translate("splStandard", "hit", nullptr));
        leEinsatz->setText(QCoreApplication::translate("splStandard", "Einsatz :", nullptr));
        txtedtCash->setHtml(QCoreApplication::translate("splStandard", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'MS Shell Dlg 2'; font-size:8.25pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:28pt;\">Kontostand : </span></p></body></html>", nullptr));
        btnSwitch->setText(QCoreApplication::translate("splStandard", "Tisch wechseln", nullptr));
    } // retranslateUi

};

namespace Ui {
    class splStandard: public Ui_splStandard {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SPLSTANDARD_H
