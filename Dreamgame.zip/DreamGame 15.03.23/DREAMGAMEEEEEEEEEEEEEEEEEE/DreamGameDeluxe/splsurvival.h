#ifndef SPLSURVIVAL_H
#define SPLSURVIVAL_H

#include <QWidget>
#include "kartenliste.h"
#include "karte.h"
//(Mahmud)

namespace Ui {
class splSurvival;
}

class splSurvival : public QWidget
{
    Q_OBJECT

public:
    explicit splSurvival(QWidget *parent = nullptr);
    ~splSurvival();

private slots:
    void on_btnSwitch_clicked();
    void liste();

private:
    Ui::splSurvival *ui;
    KListe kartendeck;
};

#endif // SPLSURVIVAL_H
