#ifndef SPLBLITZ_H
#define SPLBLITZ_H

#include <QWidget>
#include "kartenliste.h"
#include "karte.h"
//(Mahmud)

namespace Ui {
class splBlitz;
}

class splBlitz : public QWidget
{
    Q_OBJECT

public:
    explicit splBlitz(QWidget *parent = nullptr);
    ~splBlitz();

private slots:
    void on_btnSwitch_clicked();
    void liste();

private:
    Ui::splBlitz *ui;
    QWidget *hauptfenster;
    KListe kartendeck;
};

#endif // SPLBLITZ_H
