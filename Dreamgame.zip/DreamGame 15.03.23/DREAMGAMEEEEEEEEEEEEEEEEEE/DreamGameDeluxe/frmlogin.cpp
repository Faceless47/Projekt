#include "frmlogin.h"
#include "ui_frmlogin.h"
//(Mahmud)

frmLogin::frmLogin(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::frmLogin)
{
    ui->setupUi(this);

    // datenbankverbindung(mahmud)
    db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("C:/Users/mahmu/OneDrive/Dokumente/build-DreamGameDeluxe-Desktop_Qt_5_12_11_MinGW_32_bit-Debug/debug/dreamgame.sqlite");

    if(!db.open()){
        ui->lblCnct->setText("Verbindung Fehlgeschlagen!");
    }
    else {
        ui->lblCnct->setText("verbindung zum server erfolgreich!");
    }
}

frmLogin::~frmLogin()
{
    delete ui;
}

void frmLogin::on_btnLogin_clicked()
{

    // Verbindung zur Datenbank herstellen
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("C:/Users/mahmu/OneDrive/Dokumente/build-DreamGameDeluxe-Desktop_Qt_5_12_11_MinGW_32_bit-Debug/debug/dreamgame.sqlite");

    // Überprüfen, ob die Verbindung zur Datenbank hergestellt werden kann
    if (!db.open()) {
        qDebug() << "Fehler beim Öffnen der Datenbankverbindung";
        return;
    }

    // Benutzereingaben abrufen
    QString username = ui->leUName->text();
    QString password = ui->lePassword->text();

    // SQL-Abfrage vorbereiten
    QSqlQuery query;
    query.prepare("SELECT * FROM users WHERE Uname = :username AND Upassword = :password");
    query.bindValue(":username", username);
    query.bindValue(":password", password);

    // SQL-Abfrage ausführen
    if (!query.exec()) {
        qDebug() << "Fehler beim Ausführen der SQL-Abfrage";
        return;
    }

    // Überprüfen, ob ein Benutzer gefunden wurde
    if (query.next())
    {
        qDebug() << "Benutzername und Passwort korrekt";
        //den Benutzer zum Welcome screen leiten
        ui->btnLogin->hide();
        ui->lePassword->hide();
        ui->lblCmd->hide();
        ui->lblCnct->hide();
        ui->lblPic->hide();
        ui->leUName->hide();

        Owelcome = new frmWelcome(this);
        Owelcome->show();

    }


    else
    {
        qDebug() << "Benutzername oder Passwort inkorrekt";

        //den Benutzer über die inkorrekten Anmeldedaten zu informieren
        box.setText("Benutzername oder Passwort inkorrekt");

    }
}


void frmLogin::on_leUName_returnPressed()
{
    on_btnLogin_clicked();
}


void frmLogin::on_lePassword_returnPressed()
{
    on_btnLogin_clicked();
}




