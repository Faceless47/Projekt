#ifndef KARTE_H
#define KARTE_H
#include "QString"
#include "qpixmap.h"
//(Jannik)

class karte
{
public:
    karte();
};



class Karten{
private:
    QString speicherPfad;
    int wert;
    QPixmap karte;
public:
    Karten(QString pfad,int Kartenwert);
    int getKartenWert();
    QPixmap getKartenBild();
};

#endif // KARTE_H
