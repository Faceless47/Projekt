#include "karte.h"
#include "qpixmap.h"
//(Jannik)
karte::karte()
{

}

Karten::Karten(QString pfad,int kartenWert){
    this->speicherPfad=pfad;
    this->wert=kartenWert;
}

int Karten::getKartenWert(){
    return this->wert;
}

QPixmap Karten::getKartenBild(){
    return this->karte;
}
