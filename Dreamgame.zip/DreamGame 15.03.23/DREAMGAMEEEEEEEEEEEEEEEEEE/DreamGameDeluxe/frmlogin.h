#ifndef FRMLOGIN_H
#define FRMLOGIN_H

#include "frmadmincenter.h"
#include "frmwelcome.h"
#include <QMessageBox>
#include <QtSql>
#include <QDebug>
#include <QFileInfo>

#include <QWidget>
//(Mahmud)

namespace Ui {
class frmLogin;
}

class frmLogin : public QWidget
{
    Q_OBJECT

public:
    explicit frmLogin(QWidget *parent = nullptr);
    ~frmLogin();

private slots:

    void on_leUName_returnPressed();

    void on_lePassword_returnPressed();

    void on_btnLogin_clicked();

private:
    Ui::frmLogin *ui;
    QSqlDatabase db;
    frmAdminCenter *Oadmin;
    frmWelcome *Owelcome;
    QMessageBox box;
};

#endif // FRMLOGIN_H
