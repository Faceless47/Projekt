#include "frmwelcome.h"
#include "ui_frmwelcome.h"
//(Mahmud)

frmWelcome::frmWelcome(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::frmWelcome)
{
    ui->setupUi(this);
}

frmWelcome::~frmWelcome()
{
    delete ui;
}
 /*
    Oreg = new frmRegister(this);
    Oreg->show();
*/
void frmWelcome::on_btnBlitz_clicked()
{
    Oblitz = new splBlitz(this);
    Oblitz->show();



        //Löschen aller Widgets auf dem Formular (Mahmud)

ui->btnBlitz->hide();

ui->btnStd->hide();

ui->btnSvvl->hide();

ui->lblPic->hide();

ui->lblCash->hide();

ui->lblWelcome->hide();
}


void frmWelcome::on_btnStd_clicked()
{
    Ostandard = new splStandard(this);
    Ostandard->show();



        //Löschen aller Widgets auf dem Formular (Mahmud)

ui->btnBlitz->hide();

ui->btnStd->hide();

ui->btnSvvl->hide();

ui->lblPic->hide();

ui->lblCash->hide();

ui->lblWelcome->hide();
}


void frmWelcome::on_btnSvvl_clicked()
{
    Osurvival = new splSurvival(this);
    Osurvival->show();



        //Löschen aller Widgets auf dem Formular (Mahmud)

ui->btnBlitz->hide();

ui->btnStd->hide();

ui->btnSvvl->hide();

ui->lblPic->hide();

ui->lblCash->hide();

ui->lblWelcome->hide();
}

