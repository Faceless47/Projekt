#ifndef SPLSTANDARD_H
#define SPLSTANDARD_H

#include <QWidget>
#include "kartenliste.h"
#include "karte.h"
//(Mahmud)

namespace Ui {
class splStandard;
}

class splStandard : public QWidget
{
    Q_OBJECT

public:
    explicit splStandard(QWidget *parent = nullptr);
    ~splStandard();

private slots:
    void on_btnSwitch_clicked();
    void liste();

private:
    Ui::splStandard *ui;
    KListe kartendeck;
};
#endif // SPLSTANDARD_H
