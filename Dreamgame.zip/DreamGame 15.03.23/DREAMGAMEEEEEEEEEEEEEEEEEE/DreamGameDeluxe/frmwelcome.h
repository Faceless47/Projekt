#ifndef FRMWELCOME_H
#define FRMWELCOME_H
#include "splblitz.h"
#include "splstandard.h"
#include "splsurvival.h"
#include <QWidget>
//(Mahmud)

namespace Ui {
class frmWelcome;
}

class frmWelcome : public QWidget
{
    Q_OBJECT

public:
    explicit frmWelcome(QWidget *parent = nullptr);
    ~frmWelcome();

private slots:
    void on_btnBlitz_clicked();

    void on_btnStd_clicked();

    void on_btnSvvl_clicked();

private:
    Ui::frmWelcome *ui;
    splBlitz *Oblitz;
    splStandard *Ostandard;
    splSurvival *Osurvival;
};

#endif // FRMWELCOME_H
