#include "frmadmincenter.h"
#include "ui_frmadmincenter.h"
//(Mahmud)

frmAdminCenter::frmAdminCenter(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::frmAdminCenter)
{
    ui->setupUi(this);
}

frmAdminCenter::~frmAdminCenter()
{
    delete ui;
}

void frmAdminCenter::on_btnLogout_clicked()
{
     close();
}


void frmAdminCenter::on_btnPlay_clicked()
{
    ui->btnCngMoney->hide();
    ui->btnDltUser->hide();
    ui->btnLogout->hide();
    ui->btnPlay->hide();
    ui->lblPic->hide();
    ui->lblSave->hide();
    ui->lblUserInf->hide();
    ui->lblUserSlct->hide();
    ui->lwUData->hide();
    ui->cboxUser->hide();


    Owelcome = new frmWelcome(this);
    Owelcome->show();
}

