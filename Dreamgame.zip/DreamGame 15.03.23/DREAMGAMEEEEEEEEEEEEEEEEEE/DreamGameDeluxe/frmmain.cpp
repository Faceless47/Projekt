#include "frmmain.h"
#include "ui_frmmain.h"
//(Mahmud)

frmMain::frmMain(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::frmMain)
{
    ui->setupUi(this);
}

frmMain::~frmMain()
{
    delete ui;
}


void frmMain::on_btnLogin_clicked()
{
    Olog = new frmLogin(this);
    Olog->show();



        //Löschen aller Widgets auf dem Formular (Mahmud)

ui->btnLogin->hide();

ui->btnRegister->hide();

ui->lblpic->hide();
}


void frmMain::on_btnRegister_clicked()
{
    Oreg = new frmRegister(this);
    Oreg->show();



        //Löschen aller Widgets auf dem Formular (Mahmud)

ui->btnLogin->hide();

ui->btnRegister->hide();

ui->lblpic->hide();
}

