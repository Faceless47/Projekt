#include "kartenliste.h"
//(Jannik)

kartenliste::kartenliste(){

}

void KListe::appendKarte(Karten karte){
    this->kartendeck.append(karte);
}

Karten KListe::getKarte(int index){
    return this->kartendeck[index];
}

void KListe::alleKartenLoschen(){
    this->kartendeck.clear();
}
