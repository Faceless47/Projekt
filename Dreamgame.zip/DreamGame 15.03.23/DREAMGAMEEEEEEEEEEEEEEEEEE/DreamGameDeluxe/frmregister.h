#ifndef FRMREGISTER_H
#define FRMREGISTER_H
#include "frmlogin.h"
#include <QWidget>
//(Mahmud)

namespace Ui {
class frmRegister;
}

class frmRegister : public QWidget
{
    Q_OBJECT

public:
    explicit frmRegister(QWidget *parent = nullptr);
    ~frmRegister();

private slots:
    void on_btnReg_clicked();

    void on_leUName_returnPressed();

    void on_leUPassword_returnPressed();

    void on_leUPassword_2_returnPressed();

private:
    Ui::frmRegister *ui;
  frmLogin *Olog;
};

#endif // FRMREGISTER_H
