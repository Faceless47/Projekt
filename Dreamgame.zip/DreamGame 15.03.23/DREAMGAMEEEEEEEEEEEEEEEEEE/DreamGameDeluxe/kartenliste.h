#ifndef KARTENLISTE_H
#define KARTENLISTE_H
#include "QList"
#include "karte.h"
//(Jannik)
class kartenliste
{
private:
    QList<Karten>kartendeck;
public:
    kartenliste();
};

class KListe{
private:
    QList<Karten>kartendeck;
public:
    void appendKarte(Karten karte);
    Karten getKarte(int index);
    void alleKartenLoschen();
};

#endif // KARTENLISTE_H
