#include "splblitz.h"
#include "ui_splblitz.h"
#include "karte.h"
//(Jannik)
splBlitz::splBlitz(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::splBlitz)
{
    ui->setupUi(this);

}

splBlitz::~splBlitz()
{
    delete ui;
}

void splBlitz::on_btnSwitch_clicked()//(Mahmud)

{
    ui->btnHit->hide();
    ui->btnStand->hide();
    ui->btnSwitch->hide();
    ui->leEinsatz->hide();
    ui->tmedtTimer->hide();
    ui->txtedtCash->hide();


}

void splBlitz::liste(){
    Karten karte1(QApplication::applicationDirPath()+"/Karten/2_Herz.png",2);
    Karten karte2(QApplication::applicationDirPath()+"/Karten/2_Karo.png",2);
    Karten karte3(QApplication::applicationDirPath()+"/Karten/2_Kreuz.png",2);
    Karten karte4(QApplication::applicationDirPath()+"/Karten/2_Pik.png",2);
    Karten karte5(QApplication::applicationDirPath()+"/Karten/3_Herz.png",3);
    Karten karte6(QApplication::applicationDirPath()+"/Karten/3_Karo.png",3);
    Karten karte7(QApplication::applicationDirPath()+"/Karten/3_Kreuz.png",3);
    Karten karte8(QApplication::applicationDirPath()+"/Karten/3_Pik.png",3);
    Karten karte9(QApplication::applicationDirPath()+"/Karten/4_Herz.png",4);
    Karten karte10(QApplication::applicationDirPath()+"/Karten/4_Karo.png",4);
    Karten karte11(QApplication::applicationDirPath()+"/Karten/4_Kreuz.png",4);
    Karten karte12(QApplication::applicationDirPath()+"/Karten/4_Pik.png",4);
    Karten karte13(QApplication::applicationDirPath()+"/Karten/5_Herz.png",5);
    Karten karte14(QApplication::applicationDirPath()+"/Karten/5_Karo.png",5);
    Karten karte15(QApplication::applicationDirPath()+"/Karten/5_Kreuz.png",5);
    Karten karte16(QApplication::applicationDirPath()+"/Karten/5_Pik.png",5);
    Karten karte17(QApplication::applicationDirPath()+"/Karten/6_Herz.png",6);
    Karten karte18(QApplication::applicationDirPath()+"/Karten/6_Karo.png",6);
    Karten karte19(QApplication::applicationDirPath()+"/Karten/6_Kreuz.png",6);
    Karten karte20(QApplication::applicationDirPath()+"/Karten/6_Pik.png",6);
    Karten karte21(QApplication::applicationDirPath()+"/Karten/7_Herz.png",7);
    Karten karte22(QApplication::applicationDirPath()+"/Karten/7_Karo.png",7);
    Karten karte23(QApplication::applicationDirPath()+"/Karten/7_Kreuz.png",7);
    Karten karte24(QApplication::applicationDirPath()+"/Karten/7_Pik.png",7);
    Karten karte25(QApplication::applicationDirPath()+"/Karten/8_Herz.png",8);
    Karten karte26(QApplication::applicationDirPath()+"/Karten/8_Karo.png",8);
    Karten karte27(QApplication::applicationDirPath()+"/Karten/8_Kreuz.png",8);
    Karten karte28(QApplication::applicationDirPath()+"/Karten/8_Pik.png",8);
    Karten karte29(QApplication::applicationDirPath()+"/Karten/9_Herz.png",9);
    Karten karte30(QApplication::applicationDirPath()+"/Karten/9_Karo.png",9);
    Karten karte31(QApplication::applicationDirPath()+"/Karten/9_Kreuz.png",9);
    Karten karte32(QApplication::applicationDirPath()+"/Karten/9_Pik.png",9);
    Karten karte33(QApplication::applicationDirPath()+"/Karten/10_Herz.png",10);
    Karten karte34(QApplication::applicationDirPath()+"/Karten/10_Karo.png",10);
    Karten karte35(QApplication::applicationDirPath()+"/Karten/10_Kreuz.png",10);
    Karten karte36(QApplication::applicationDirPath()+"/Karten/10_Pik.png",10);
    Karten karte37(QApplication::applicationDirPath()+"/Karten/Bube_Herz.png",10);
    Karten karte38(QApplication::applicationDirPath()+"/Karten/Bube_Karo.png",10);
    Karten karte39(QApplication::applicationDirPath()+"/Karten/Bube_Kreuz.png",10);
    Karten karte40(QApplication::applicationDirPath()+"/Karten/Bube_Pik.png",10);
    Karten karte41(QApplication::applicationDirPath()+"/Karten/Dame_Herz.png",10);
    Karten karte42(QApplication::applicationDirPath()+"/Karten/Dame_Karo.png",10);
    Karten karte43(QApplication::applicationDirPath()+"/Karten/Dame_Kreuz.png",10);
    Karten karte44(QApplication::applicationDirPath()+"/Karten/Dame_Pik.png",10);
    Karten karte45(QApplication::applicationDirPath()+"/Karten/König_Herz.png",10);
    Karten karte46(QApplication::applicationDirPath()+"/Karten/König_Karo.png",10);
    Karten karte47(QApplication::applicationDirPath()+"/Karten/König_Kreuz.png",10);
    Karten karte48(QApplication::applicationDirPath()+"/Karten/König_Pik.png",10);
    Karten karte49(QApplication::applicationDirPath()+"/Karten/Ass_Herz.png",11);
    Karten karte50(QApplication::applicationDirPath()+"/Karten/Ass_Karo.png",11);
    Karten karte51(QApplication::applicationDirPath()+"/Karten/Ass_Kreuz.png",11);
    Karten karte52(QApplication::applicationDirPath()+"/Karten/Ass_Pik.png",11);


    kartendeck.appendKarte(karte1);
    kartendeck.appendKarte(karte2);
    kartendeck.appendKarte(karte3);
    kartendeck.appendKarte(karte4);
    kartendeck.appendKarte(karte5);
    kartendeck.appendKarte(karte6);
    kartendeck.appendKarte(karte7);
    kartendeck.appendKarte(karte8);
    kartendeck.appendKarte(karte9);
    kartendeck.appendKarte(karte10);
    kartendeck.appendKarte(karte11);
    kartendeck.appendKarte(karte12);
    kartendeck.appendKarte(karte13);
    kartendeck.appendKarte(karte14);
    kartendeck.appendKarte(karte15);
    kartendeck.appendKarte(karte16);
    kartendeck.appendKarte(karte17);
    kartendeck.appendKarte(karte18);
    kartendeck.appendKarte(karte19);
    kartendeck.appendKarte(karte20);
    kartendeck.appendKarte(karte21);
    kartendeck.appendKarte(karte22);
    kartendeck.appendKarte(karte23);
    kartendeck.appendKarte(karte24);
    kartendeck.appendKarte(karte25);
    kartendeck.appendKarte(karte26);
    kartendeck.appendKarte(karte27);
    kartendeck.appendKarte(karte28);
    kartendeck.appendKarte(karte29);
    kartendeck.appendKarte(karte30);
    kartendeck.appendKarte(karte31);
    kartendeck.appendKarte(karte32);
    kartendeck.appendKarte(karte33);
    kartendeck.appendKarte(karte34);
    kartendeck.appendKarte(karte35);
    kartendeck.appendKarte(karte36);
    kartendeck.appendKarte(karte37);
    kartendeck.appendKarte(karte38);
    kartendeck.appendKarte(karte39);
    kartendeck.appendKarte(karte40);
    kartendeck.appendKarte(karte41);
    kartendeck.appendKarte(karte42);
    kartendeck.appendKarte(karte43);
    kartendeck.appendKarte(karte44);
    kartendeck.appendKarte(karte45);
    kartendeck.appendKarte(karte46);
    kartendeck.appendKarte(karte47);
    kartendeck.appendKarte(karte48);
    kartendeck.appendKarte(karte49);
    kartendeck.appendKarte(karte50);
    kartendeck.appendKarte(karte51);
    kartendeck.appendKarte(karte52);


}


