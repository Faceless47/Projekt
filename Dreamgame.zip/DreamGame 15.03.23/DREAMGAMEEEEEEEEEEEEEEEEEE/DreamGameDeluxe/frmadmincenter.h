#ifndef FRMADMINCENTER_H
#define FRMADMINCENTER_H
#include "frmwelcome.h"
#include "frmwelcome.h"
#include <QWidget>
//(Mahmud)
namespace Ui {
class frmAdminCenter;
}

class frmAdminCenter : public QWidget
{
    Q_OBJECT

public:
    explicit frmAdminCenter(QWidget *parent = nullptr);
    ~frmAdminCenter();

private slots:
    void on_btnLogout_clicked();

    void on_btnPlay_clicked();

private:
    Ui::frmAdminCenter *ui;
     frmWelcome *Owelcome;

};

#endif // FRMADMINCENTER_H
