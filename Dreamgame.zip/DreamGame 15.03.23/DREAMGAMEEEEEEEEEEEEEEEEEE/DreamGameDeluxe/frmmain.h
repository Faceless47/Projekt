#ifndef FRMMAIN_H
#define FRMMAIN_H
#include "frmregister.h"
#include "frmlogin.h"
#include <QMainWindow>
//(Mahmud)

QT_BEGIN_NAMESPACE
namespace Ui { class frmMain; }
QT_END_NAMESPACE

class frmMain : public QMainWindow
{
    Q_OBJECT

public:
    frmMain(QWidget *parent = nullptr);
    ~frmMain();

private slots:
    void on_btnLogin_clicked();

    void on_btnRegister_clicked();

private:
    Ui::frmMain *ui;
    frmLogin *Olog;
    frmRegister *Oreg;
};
#endif // FRMMAIN_H
