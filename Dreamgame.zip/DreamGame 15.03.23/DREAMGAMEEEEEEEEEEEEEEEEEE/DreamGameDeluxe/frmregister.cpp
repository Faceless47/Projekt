#include "frmregister.h"
#include "ui_frmregister.h"
//(Mahmud)

frmRegister::frmRegister(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::frmRegister)
{
    ui->setupUi(this);
}

frmRegister::~frmRegister()
{
    delete ui;
}

void frmRegister::on_btnReg_clicked()

    {
    // Verbindung zur Datenbank herstellen
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("C:/Users/mahmu/OneDrive/Dokumente/build-DreamGameDeluxe-Desktop_Qt_5_12_11_MinGW_32_bit-Debug/debug/dreamgame.sqlite");

    // Überprüfen, ob die Verbindung zur Datenbank hergestellt werden kann
    if (!db.open()) {
        qDebug() << "Fehler beim Öffnen der Datenbankverbindung";
        return;
    }
        // Benutzereingaben abrufen
        QString username = ui->leUName->text();
        QString password = ui->leUPassword->text();
        QString confirm_password = ui->leUPassword_2->text();

        // Überprüfen, ob das Passwort und die Bestätigung des Passworts übereinstimmen
        if (password != confirm_password) {
            qDebug() << "Die Passwörter stimmen nicht überein";
            return;
        }

        // Überprüfen, ob der Benutzername bereits in der Datenbank vorhanden ist
        QSqlQuery check_query;
        check_query.prepare("SELECT * FROM users WHERE username = :username");
        check_query.bindValue(":username", username);
        if (check_query.exec() && check_query.next()) {
            qDebug() << "Der Benutzername ist bereits vergeben";
            return;
        }

        // SQL-Abfrage vorbereiten, um den neuen Benutzer in die Datenbank einzufügen
        QSqlQuery query;
        query.prepare("INSERT INTO users (username, password) VALUES (:username, :password)");
        query.bindValue(":username", username);
        query.bindValue(":password", password);

        // SQL-Abfrage ausführen
        if (!query.exec()) {
            qDebug() << "Fehler beim Einfügen des neuen Benutzers";
            return;
        }

        qDebug() << "Der neue Benutzer wurde erfolgreich registriert";
        // Hier können Sie den Code einfügen, um den Benutzer zur Hauptanwendung zu leiten
    }




void frmRegister::on_leUName_returnPressed()
{
    on_btnReg_clicked();
}


void frmRegister::on_leUPassword_returnPressed()
{
      on_btnReg_clicked();
}


void frmRegister::on_leUPassword_2_returnPressed()
{
    on_btnReg_clicked();

}

