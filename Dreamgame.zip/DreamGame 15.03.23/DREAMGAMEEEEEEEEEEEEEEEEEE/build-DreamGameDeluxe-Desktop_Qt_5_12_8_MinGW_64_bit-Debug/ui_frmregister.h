/********************************************************************************
** Form generated from reading UI file 'frmregister.ui'
**
** Created by: Qt User Interface Compiler version 5.12.8
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FRMREGISTER_H
#define UI_FRMREGISTER_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_frmRegister
{
public:
    QLabel *lblname;
    QLineEdit *leUPassword;
    QLabel *lblPass;
    QPushButton *btnReg;
    QLabel *lblPic;
    QLineEdit *leUName;

    void setupUi(QWidget *frmRegister)
    {
        if (frmRegister->objectName().isEmpty())
            frmRegister->setObjectName(QString::fromUtf8("frmRegister"));
        frmRegister->resize(800, 600);
        lblname = new QLabel(frmRegister);
        lblname->setObjectName(QString::fromUtf8("lblname"));
        lblname->setGeometry(QRect(60, 66, 321, 20));
        QFont font;
        font.setPointSize(18);
        lblname->setFont(font);
        leUPassword = new QLineEdit(frmRegister);
        leUPassword->setObjectName(QString::fromUtf8("leUPassword"));
        leUPassword->setGeometry(QRect(60, 270, 201, 61));
        QFont font1;
        font1.setPointSize(14);
        leUPassword->setFont(font1);
        lblPass = new QLabel(frmRegister);
        lblPass->setObjectName(QString::fromUtf8("lblPass"));
        lblPass->setGeometry(QRect(60, 230, 271, 31));
        lblPass->setFont(font);
        btnReg = new QPushButton(frmRegister);
        btnReg->setObjectName(QString::fromUtf8("btnReg"));
        btnReg->setGeometry(QRect(400, 420, 321, 111));
        QFont font2;
        font2.setPointSize(16);
        btnReg->setFont(font2);
        lblPic = new QLabel(frmRegister);
        lblPic->setObjectName(QString::fromUtf8("lblPic"));
        lblPic->setGeometry(QRect(0, 0, 801, 601));
        lblPic->setFont(font);
        lblPic->setPixmap(QPixmap(QString::fromUtf8("../../Desktop/projekt sschule/green dg.png")));
        lblPic->setScaledContents(true);
        leUName = new QLineEdit(frmRegister);
        leUName->setObjectName(QString::fromUtf8("leUName"));
        leUName->setGeometry(QRect(60, 100, 201, 61));
        leUName->setFont(font1);
        lblPic->raise();
        lblname->raise();
        leUPassword->raise();
        lblPass->raise();
        btnReg->raise();
        leUName->raise();

        retranslateUi(frmRegister);

        QMetaObject::connectSlotsByName(frmRegister);
    } // setupUi

    void retranslateUi(QWidget *frmRegister)
    {
        frmRegister->setWindowTitle(QApplication::translate("frmRegister", "Form", nullptr));
        lblname->setText(QApplication::translate("frmRegister", "w\303\244hlen sie einen Usernamen", nullptr));
        leUPassword->setText(QString());
        lblPass->setText(QApplication::translate("frmRegister", "w\303\244hlen sie ein Passwort", nullptr));
        btnReg->setText(QApplication::translate("frmRegister", "registrieren", nullptr));
        lblPic->setText(QString());
        leUName->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class frmRegister: public Ui_frmRegister {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FRMREGISTER_H
