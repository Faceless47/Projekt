/********************************************************************************
** Form generated from reading UI file 'frmadmincenter.ui'
**
** Created by: Qt User Interface Compiler version 5.12.8
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FRMADMINCENTER_H
#define UI_FRMADMINCENTER_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_frmAdminCenter
{
public:
    QPushButton *btnLogout;
    QComboBox *cboxUser;
    QListWidget *lwUData;
    QLabel *lblUserInf;
    QPushButton *btnCngMoney;
    QPushButton *btnPlay;
    QPushButton *btnDltUser;
    QLabel *lblUserSlct;
    QPushButton *lblSave;
    QLabel *lblPic;

    void setupUi(QWidget *frmAdminCenter)
    {
        if (frmAdminCenter->objectName().isEmpty())
            frmAdminCenter->setObjectName(QString::fromUtf8("frmAdminCenter"));
        frmAdminCenter->resize(800, 600);
        btnLogout = new QPushButton(frmAdminCenter);
        btnLogout->setObjectName(QString::fromUtf8("btnLogout"));
        btnLogout->setGeometry(QRect(30, 520, 161, 61));
        cboxUser = new QComboBox(frmAdminCenter);
        cboxUser->addItem(QString());
        cboxUser->addItem(QString());
        cboxUser->addItem(QString());
        cboxUser->addItem(QString());
        cboxUser->setObjectName(QString::fromUtf8("cboxUser"));
        cboxUser->setGeometry(QRect(30, 100, 301, 41));
        lwUData = new QListWidget(frmAdminCenter);
        lwUData->setObjectName(QString::fromUtf8("lwUData"));
        lwUData->setGeometry(QRect(20, 220, 711, 201));
        lblUserInf = new QLabel(frmAdminCenter);
        lblUserInf->setObjectName(QString::fromUtf8("lblUserInf"));
        lblUserInf->setGeometry(QRect(20, 150, 291, 61));
        QFont font;
        font.setPointSize(14);
        lblUserInf->setFont(font);
        btnCngMoney = new QPushButton(frmAdminCenter);
        btnCngMoney->setObjectName(QString::fromUtf8("btnCngMoney"));
        btnCngMoney->setGeometry(QRect(580, 520, 161, 61));
        btnPlay = new QPushButton(frmAdminCenter);
        btnPlay->setObjectName(QString::fromUtf8("btnPlay"));
        btnPlay->setGeometry(QRect(210, 520, 161, 61));
        btnDltUser = new QPushButton(frmAdminCenter);
        btnDltUser->setObjectName(QString::fromUtf8("btnDltUser"));
        btnDltUser->setGeometry(QRect(390, 520, 161, 61));
        lblUserSlct = new QLabel(frmAdminCenter);
        lblUserSlct->setObjectName(QString::fromUtf8("lblUserSlct"));
        lblUserSlct->setGeometry(QRect(30, 70, 251, 21));
        lblUserSlct->setFont(font);
        lblSave = new QPushButton(frmAdminCenter);
        lblSave->setObjectName(QString::fromUtf8("lblSave"));
        lblSave->setGeometry(QRect(30, 450, 161, 61));
        lblPic = new QLabel(frmAdminCenter);
        lblPic->setObjectName(QString::fromUtf8("lblPic"));
        lblPic->setGeometry(QRect(0, 0, 801, 601));
        lblPic->setPixmap(QPixmap(QString::fromUtf8("../../Desktop/projekt sschule/orange dg.png")));
        lblPic->setScaledContents(true);
        lblPic->raise();
        btnLogout->raise();
        cboxUser->raise();
        lwUData->raise();
        lblUserInf->raise();
        btnCngMoney->raise();
        btnPlay->raise();
        btnDltUser->raise();
        lblUserSlct->raise();
        lblSave->raise();

        retranslateUi(frmAdminCenter);

        QMetaObject::connectSlotsByName(frmAdminCenter);
    } // setupUi

    void retranslateUi(QWidget *frmAdminCenter)
    {
        frmAdminCenter->setWindowTitle(QApplication::translate("frmAdminCenter", "Form", nullptr));
        btnLogout->setText(QApplication::translate("frmAdminCenter", "logout", nullptr));
        cboxUser->setItemText(0, QApplication::translate("frmAdminCenter", "Neues Element1", nullptr));
        cboxUser->setItemText(1, QApplication::translate("frmAdminCenter", "Neues Element2", nullptr));
        cboxUser->setItemText(2, QApplication::translate("frmAdminCenter", "Neues Element", nullptr));
        cboxUser->setItemText(3, QApplication::translate("frmAdminCenter", "Neues Element", nullptr));

        lblUserInf->setText(QApplication::translate("frmAdminCenter", "user informationen", nullptr));
        btnCngMoney->setText(QApplication::translate("frmAdminCenter", "geld bearbeiten", nullptr));
        btnPlay->setText(QApplication::translate("frmAdminCenter", "zum welcomescreen", nullptr));
        btnDltUser->setText(QApplication::translate("frmAdminCenter", "nutzer l\303\266schen", nullptr));
        lblUserSlct->setText(QApplication::translate("frmAdminCenter", "user W\303\244hlen", nullptr));
        lblSave->setText(QApplication::translate("frmAdminCenter", "\303\244nderrungen speichern", nullptr));
        lblPic->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class frmAdminCenter: public Ui_frmAdminCenter {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FRMADMINCENTER_H
