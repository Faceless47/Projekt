/********************************************************************************
** Form generated from reading UI file 'frmlogin.ui'
**
** Created by: Qt User Interface Compiler version 5.12.8
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FRMLOGIN_H
#define UI_FRMLOGIN_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_frmLogin
{
public:
    QLineEdit *lePassword;
    QLineEdit *leUName;
    QLabel *lblCmd;
    QPushButton *btnLog;
    QLabel *lblPic;
    QLabel *lblCnct;

    void setupUi(QWidget *frmLogin)
    {
        if (frmLogin->objectName().isEmpty())
            frmLogin->setObjectName(QString::fromUtf8("frmLogin"));
        frmLogin->resize(800, 600);
        lePassword = new QLineEdit(frmLogin);
        lePassword->setObjectName(QString::fromUtf8("lePassword"));
        lePassword->setGeometry(QRect(50, 260, 301, 71));
        lePassword->setEchoMode(QLineEdit::Password);
        leUName = new QLineEdit(frmLogin);
        leUName->setObjectName(QString::fromUtf8("leUName"));
        leUName->setEnabled(true);
        leUName->setGeometry(QRect(50, 160, 301, 71));
        QFont font;
        font.setBold(false);
        font.setWeight(50);
        leUName->setFont(font);
        leUName->setClearButtonEnabled(false);
        lblCmd = new QLabel(frmLogin);
        lblCmd->setObjectName(QString::fromUtf8("lblCmd"));
        lblCmd->setGeometry(QRect(40, 60, 351, 71));
        QFont font1;
        font1.setFamily(QString::fromUtf8("Monotype Corsiva"));
        font1.setPointSize(24);
        font1.setItalic(true);
        lblCmd->setFont(font1);
        btnLog = new QPushButton(frmLogin);
        btnLog->setObjectName(QString::fromUtf8("btnLog"));
        btnLog->setGeometry(QRect(50, 400, 201, 91));
        lblPic = new QLabel(frmLogin);
        lblPic->setObjectName(QString::fromUtf8("lblPic"));
        lblPic->setGeometry(QRect(0, 0, 801, 601));
        lblPic->setFont(font1);
        lblPic->setPixmap(QPixmap(QString::fromUtf8("../../Desktop/projekt sschule/black dg.png")));
        lblPic->setScaledContents(true);
        lblCnct = new QLabel(frmLogin);
        lblCnct->setObjectName(QString::fromUtf8("lblCnct"));
        lblCnct->setGeometry(QRect(270, 380, 511, 211));
        lblCnct->setFont(font1);
        lblPic->raise();
        lePassword->raise();
        leUName->raise();
        lblCmd->raise();
        btnLog->raise();
        lblCnct->raise();

        retranslateUi(frmLogin);

        QMetaObject::connectSlotsByName(frmLogin);
    } // setupUi

    void retranslateUi(QWidget *frmLogin)
    {
        frmLogin->setWindowTitle(QApplication::translate("frmLogin", "Form", nullptr));
        lePassword->setText(QString());
        lePassword->setPlaceholderText(QApplication::translate("frmLogin", "Password", nullptr));
        leUName->setText(QString());
        leUName->setPlaceholderText(QApplication::translate("frmLogin", "Username", nullptr));
        lblCmd->setText(QApplication::translate("frmLogin", "bitte melden sie sich an", nullptr));
        btnLog->setText(QApplication::translate("frmLogin", "Login", nullptr));
        lblPic->setText(QString());
        lblCnct->setText(QApplication::translate("frmLogin", "Verbindung zum server wird hergestellt... \n"
"  \n"
"  wenn sie nicht verbunden werden, \n"
" starten sie das Programm neu oder  \n"
" melden sie sich an den Programmierern", nullptr));
    } // retranslateUi

};

namespace Ui {
    class frmLogin: public Ui_frmLogin {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FRMLOGIN_H
